******************************************************************************
|Descent Manager ANIBUILDER32 V1.0 | http://www.descent-network.com/descman  |
|    Code by HH-Software Images    |                                         |
| (C)1999-2000 by Descent Network  | eMail: DescMan@descent-network.com      |
|----------------------------------|                                         |
|           Documentation          | Heiko Herrmann                          |
|           Release Notes          | Descent Network Team                    |
******************************************************************************


How to install ANIBUILDER32:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- Run the installation EXE you downloaded and specify your destination
  directory. No DLLPAK is needed for this tool. However you need to have the
  font Tahoma installed. This is automatically installed by MS Office 97,
  MS Office 2000, DLLPAK and Windows 2000. If you don't have any of these
  installed, download the font from the website
  http://www.descent-network.com/descman
  and install it via the control panel.
 

What are ANI files
~~~~~~~~~~~~~~~~~~
ANI files are Volition ANImation files, so far used in their games
Conflict, Descent: FreeSpace and FreeSpace 2. This ANI file format is NOT a
standard file format and can so NOT be opened by a standard graphic tool like
Paint Shop Pro, Corel PhotoPaint, Adobe Photoshop, ACDSee or whatever.

At the current date the only tool available that can play such ANI files is
Descent Manager ANIVIEW32, which you can get at
http://www.descent-network.com/descman


Key frames
~~~~~~~~~~
Each ANI file can have any number of key frames. Key frames are frames that
are saved completely in the ANI instead of just as what pixels changed since
the previous frame. Normally ANI files in FreeSpace 1/2 have:

a) 1 keyframe (frame #0)
   The animation is played as is in the game, in most case also looped.

b) 2 keyframes (frame #0 and a "looppoint" frame)
   The animation has an "intro", only the part after the looppoint till the end
   is actually looped in the 2nd turn (e.g. the weapons and ships animations of
   the briefing screen). If you play such an ANI in ANIVIEW32 with loop enabled
   ANIVIEW32 will use this looppoint and so have the same effect as in the
   game.

c) all frames are keyframes
   The animation can be played forwards and backwards. This is the case for all
   main hall animations: its played forwards if you move the mouse pointer over
   a room, and backwards again if you move it away. If you play such an ANI in
   ANIVIEW32 with loop enabled ANIVIEW32 will play it bouncing forwards and
   backwards.

ANIVIEW32 only goes via the special loop modes as explained in b) and c), when
looping is enabled. Selecting "Previous Next frame" manually is not influenced
by the number of keyframes.

Also note that this functionality was first built into ANIVIEW32 V1.0 Beta 02c,
so make sure you have the newest version.


How to use the palette merger without loss of quality
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Since Build 03 ANIBUILDER32 has a palette merger implemented. This means if
the frames' palette do not match, the palette merger adapts the frames so that
no "color rings" will appear in the resulting animation. However, to get a
decent result, you should know how the palette merger works so that you know
its limitations.

The palette merger checks if the frame's palette merges the palette of the
first frame. If not, it translates each palette color to the color of the first
frame, that is the nearest. A 213/68/159 RGB color for example will be similar
to a 214/70/160 color, only being away from the original color by 1+2+1=4
degrees. This is done for each of the 256 palette entries, and the result
degree is being calculated by adding each of the individual palette error
degrees. This result degree is shown by ANIBUILDER32 in the status box, and
the lower the number, the better the result.

So this will correct palette errors. However, please do not overestimate the
power of the palette merger. Since it only adapts each frame to the first one,
it can only be that good as the first frame's palette represents the actual
colors used in the whole animation. If the colors in the first frame are
far away from the rest of the frame's used colors, the result will be horrible.
The result degree can be a factor of how good the representation of the first
frame was.

If you want the perfect result however, make sure your frames already have the
same palette. Or at least they use the same colors, because if there are the
same colors everywhere, just the palette order is different each time, the
result degree will be 0 which means a 100% (i.e. with no loss) palette merging
took place, which is exactly as good as identical palettes.

For an absolutely quality ANImation, you might want to force ANIBUILDER to stop
building the ANI if the palettes do not match as a warning to you, that you
should check the frames again. You can set this behaviour in the "Advanced
Settings" dialog.


Integration with ANIVIEW32
~~~~~~~~~~~~~~~~~~~~~~~~~~
ANIBUILDER32 automatically locates ANIVIEW32 if it is installed and offers to
open your generated ANI file directly in ANIVIEW32, so that you can test the
ANI file even before you start FreeSpace 1/2.

Any ANIVIEW32 version is compatible to ANIBUILDER32, starting from the first
release Beta 01. However generally it is highly recommended to get the newest
version from http://www.descent-network.com/descman


Other notes
~~~~~~~~~~~
- Usually FPS (frames per second) is always at 15. You can however specify a
  different number. Please note that the result might be strange in
  FreeSpace 1/2, so try with care. ANIVIEW32 generally even ignores the FPS
  number and always plays with a fixed value of 15 FPS.

- ANIBUILDER32 is unable to create the Windows animated cursor file format,
  which also has the file extension *.ANI. It can only create ANI files for
  the Volition titles FreeSpace 1 and FreeSpace 2.




CU in the mines...
Heiko Herrmann alias HH-Software Images from the Descent Network Team
