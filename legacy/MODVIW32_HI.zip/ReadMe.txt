******************************************************************************
| Descent Manager MODELVIEW32 V1.0 | http://www.descent-network.com/descman  |
|    Code by HH-Software Images    |                                         |
|(C)2000-02 by Descent Network Team| eMail: DescMan@descent-network.com      |
|----------------------------------|                                         |
|           Documentation          | Heiko Herrmann                          |
|           Release Notes          | Descent Network Team                    |
******************************************************************************



Welcome
~~~~~~~
Welcome to Descent Manager MODELVIEW32. This module was created to view models
from Descent 2+3 and FreeSpace 1+2 - one tool for all. It replaces and contains
the full functionality of the former tools PMVIEW, RBOTVIEW (partially),
D3VIEW, FSVIEW and FS2VIEW by Garry Knudson. However don't see this as
competition against Garry Knudson, but more as a further development - because
MODELVIEW32 uses the routines from the tools listed above curtesy of Garry (c:.

MODELVIEW32 however goes one step further than 'just' display the models. You
can fully analyse them, including listing its textures, submodels and more.
You can view individual submodels and textures - filtering the other sub-
models/textures out on the display. You can list the texture details (height,
width, number of polygons using each texture, etc.) as well as analyse an
OOF (Descent 3) or POF (FreeSpace) file's block structure. You can view the
pre-defined positions of Descent 2+3 robots, view the segments and guns
position (all games), view shields and detail versions (FreeSpace) and more.
And finally you can generate a list of all models in one archive file (*.HAM,
*.HXM, *.HOG and *.VP are supported archive files) and compare its specs: which
FreeSpace ship has the most polygons? This information might also be important
if you want to generate an own model later - you then know how many polygons
(or points, submodels, ...) are *at least* supported by the game graphic
engine.

However, please be aware that this is an early beta with a lot of bugs left to
be fixed and some functionality not yet being implemented. Refer to the Known
Bugs section below for some known problems with the module.

So then, have fun (c:.


Thanks
~~~~~~
Big thanks goes out to Garry Knudson for giving me the engines for his **VIEW
tools. So I did not have to re-invent the wheel :).

Thanks goes also as always to my good friend Steve Klinger, who helped
localizing and fixing a lot of bugs and get Garry's engines to work under
MS Visual C++ 6.

Thanks also goes to James Ku a.k.a. Kuman, who once again provided a fantastic
artwork for the splash screen.

And finally thanks goes out to all alpha and beta testers for any feedback
and bug report they provided. (See About box for a list of names)
For testing the POF editor I especially want to thank Kalle Aaltonen for
always great feedback.


Note:
~~~~~
- If you save a POF in the editor that you just extracted from the original
  FreeSpace 1/2 .VP files, the file will be a bit smaller than the original
  file, even though nothing changed. This is not a bug, there is no
  information lost. However the original Volition editors wasted some bytes
  containing nothing but null or CRLF bytes at the end of strings, which are
  however totally useless. MODELVIEW in contrast cuts strings to their actual
  content.
- If you switch on the new "Rotate Parts" mode and then switch render mode,
  the toolbar might not visually deactivate the old render mode. This happens
  only when the CPU is too busy rendering the rotation, so it depends on your
  CPU speed and the complexity of the model. As soon as you turn off "Rotate
  Parts" mode it the toolbar buttons will reflect the correct state again.


Known Bugs:
~~~~~~~~~~~
- After loading a D2/FreeSpace model, D3 models will not display right anymore
  in textured mode. No idea yet, what is causing this, and the other way
  round.
- In higher resolutions there sometimes appears a black box at the bottom of
  the model view, where models disappear. You can also see it when you change
  the background color. Restarting the tool helps against this sometimes.
- "Rotate Parts" doesn't rotate submodels correctly, whose parent submodel also
  rotates.
- As soon as you resize the main window, the right view will be reset to its
  default width size, when you have changed it using the splitter.
- Segments and guns are not yet available in D3 mode.
- Not yet all functionality is available.
- V-HAM models are incorrectly placed into cathegories (hi-res and lo-res).
- In D2 HXM and V-HAM files position information might be wrong.
- Number of polygons using a specific texture is not displayed in Model Details
  dialog in FreeSpace 1 and 2 mode.
- Many small bugs.
- Lots of functionality yet to be added.


Features:
~~~~~~~~~
- Supported games:
   Descent 2 (OEM+Full)
   Descent 3 (Full)
   Conflict, Descent: FreeSpace (Demo+OEM+Full)
   FreeSpace 2 (Demo+Full)

- Wireframe, surface and textured modes.
- Advanced model information automatically displayed.
- Advanced texture/block table/log file pane.
- Model comparison table: overview of all models of the current HAM/HOG/VP with
  information about number of vertices, polygons, etc.
- Supports directly browsing and loading from HOG and VP files.
- Supports being called from Descent Manager VPVIEW32 (VPVIEW32 V1.2 or higher
  required, when using VPVIEW32 V2.0 you must at least have Beta 02).
- Optionally marks guns and turrets on the models (not working correctly for
  Descent 3 yet).

- Descent 2:
   Selectable main PIG texture set
   (not yet implemented:) POG file can be loaded optionally
   Models are automatically identified as Robot, Reactor, Player Ship, Marker
    or weapon.
   Positions support with smooth animated change.

- Descent 3:
   Positions support
   (not yet implemented:) Rotation support

- FreeSpace 1/2:
   Detail switching
   Show/hide thrusters
   Show/hide shields
   Show/hide docking points
   Show and identify gun banks
   Show and identify subsystems
   Full POF editor


Supported file types:
~~~~~~~~~~~~~~~~~~~~~
The following file types are supported:

- Descent 2
   *.HAM (Main robot archive)
   *.HAM (V-HAM format - not from within HOG yet)
   *.HXM (HXM format - not from within HOG yet)
   (not yet implemented:) *.POL (Descent Manager HAXMEDIT32/POLYTRON32 format)

- Descent 3
   *.OOF
   *.HOG (archive with OOF files)

- FreeSpace 1/2
   *.POF
   *.VP (archive with VP files)


Tested files:
~~~~~~~~~~~~~
This viewer has been tested with the following files:

- Descent 2
   DESCENT2.HAM (Main models)
   D2X.HAM (Vertigo Series models inside D2X.HOG, you need to extract it first)
   <entropy2 models>

- Descent 3
   (demo?)
   D3.HOG (Main models)
   MERC.HOG (Mercury models)

- FreeSpace 1
   Playable Demo's FREESPACE.VP file (in \Data directory)
   FREESPACE.VP (Main models, in \Data directory)
   ROOT.VP (Some more models)
   MDISK.VP (Silent Threat models)
   (starwars mod?)

- FreeSpace 2
   Playable Demo's SPARKY_FS2.VP
   SPARKY_FS2.VP (Main models)

      
Source code
~~~~~~~~~~~
The source code is available at
http://www.descent-freespace.com/ddn/sources/modelview


Internet Explorer required
~~~~~~~~~~~~~~~~~~~~~~~~~~
Since Beta 05 MODELVIEW32 uses a HTML-based welcome and error description
screen. Internet Explorer 4 or higher is required for this functionality.
This is automatically the case if you have Windows 98 or newer or Windows
2000 or newer installed. However it is NOT necessary to have IE be the
default browser.

If you do not have IE installed, the program might crash and/or not have full
functionality.

Note:
C++ developers can compile MODELVIEW so that the old-style (pre-Beta 05)
error screen is displayed and no HTML pages are shown. This removes the IE
dependancy. To do this undefine _WITHHTVIEW in MODVIEW32Doc.h and compile.


Performance
~~~~~~~~~~~
Descent Manager MODELVIEW32 -being a full-featured model viewer- needs quite a
good system to run properly. Technically, a Pentium-system with 16 MB is
enough, as long as enough virtual memory is available via a swap file. However,
for a quick update of the model display, a Pentium 2 class CPU is highly
recommended, especially for Descent 3 and FreeSpace models (which have lots of
vertices and polygons to render). The program also needs kinda a lot of memory
to store all the model and texture data.

If you have a rather slow system or a system with not much memory installed,
and the display update is to slow while rotating etc., you can speed up the
whole progress with the following tricks:

- Make sure you are running in 15-bit or higher color mode. Go to the Display
  applet in the Control Panel and set to High Color (15/16-bit) or True
  Color (24/32-bit). If you are running under 256 colors (8-bit), the computer
  has to readapt the color palette at every single rendering step which makes
  turning, zooming and paning the model very slow. Under 16 colors (4-bit)
  the models will look very ugly, so forget that color depth completely.

- Turn off textured mode and enter surface or even wireframe mode until you
  actually need textured mode. This will not only dramatically speed up
  the time to render, but also the time to load a models, since MODELVIEW32 is
  designed to only texture data if needed.

- Reduce the size of the application window, so that due to a lower area to be
  displayed, less pixels need to be calculated.

- In FreeSpace 1/2 mode make sure "High Quality Texturing" is turned off. This
  can be found on both the toolbar as well as in the menu "View|Special
  FreeSpace settings". This makes loading the model a lot quicker, especially
  on FreeSpace 1 cruisers.

- You can also use lores versions of the models. In FreeSpace 1/2 you simply
  need to set the detail via the toolbar. In Descent 2 and 3 lores versions
  are saved as seperated files. Look for a filename with "medium", "low" or
  "LORES" in the list on the left.

- Finally, turning off guns, segments and (in FreeSpace 1/2) shields display
  can also speed up.

- Please note that "Rotate Parts" needs lots of CPU power. It is recommended
  to switch to wireframe mode before enabling it, unless you have an
  absolutely high-end computer.


Quick Start
~~~~~~~~~~~
The user interface should be pretty much self-explaining and easy to
understand. Here is some basic information:

- A model can either be loaded from a model file (like POL, POF and OOF files),
  or from model archives (like HAM, HXM, HOG and VP files). Archives are files
  that contain the information of many other files (models and other) embedded
  together with an index. When you open a model file, the model is directly
  displayed in the main view. When you open a model archive a list on the left
  pops up. By clicking an item in this list you actually open this model.

- The top toolbar is fixed and is present at all time. As soon as you load a
  model (whether from an archive or from a file directly), a second toolbar
  appears that is dependant on the game the model is for. For a FreeSpace 1/2
  model for example you see special FreeSpace options, like detail level and
  show/hide shields, while for a Descent 2 model, you can select the texture
  set and palette.

- You can turn the model by dragging the model with the left mouse pressed. (*)

- You can zoom the model by dragging the model with the right mouse pressed.(*)

- You can pane the model by having the SHIFT key pressed while dragging the
  model with any mouse button pressed.

(*) The mouse buttons can be swapped using the Options dialog.

Please make sure you are running MODELVIEW32 only in high resolutions.
800x600 is the absolute minimum, although I highly recommend 1024x768 or
higher. The application will run under 640x480, however there is not enough
place to show all controls and information bars in full, so the application
is pretty useless here. Also make sure to have at least 15-bit color depth.


POF Editor
~~~~~~~~~~
Since Beta 04 MODELVIEW contains a POF editor. The biggest advantage to other
POF utilities like FreeSpace Mission Manager (FSMM) by Scott Perry and the POF
Construction Suite by Derek Meek is that the WYSIWYG view shows you directly
the changes you do visually. Additionally you can edit things that are not
editable in the competing tools, like lights.

To start the POF editor, load any POF model. The POF file can also be inside
a VP file. To start the editor, just go to the "Editor" menu and click "Open
in POF-Editor". If you loaded a POF inside a VP it will offer you to extract
the POF file first. In both cases you will now have an additional toolbar in
which you can select the editor pane on the right. So if you for example click
on "Turrets" in the editor toolbar (or in the "Editor" menu, the right pane
will show you the turrets editor.

You can save at any time. "Save" and "Save As" commands are in the "Editor"
menu. Additionally you can at all times save FreeSpace 1 files as FreeSpace 2
files and the other way round. If you are saving as FreeSpace 1 files, the
following information is removed from the file, since it is not supported by
FreeSpace 1:
- Insignias (Squad logo position)
- TechRoom AutoCenter point

On most editor panes you will see three icons on the right, which do create
new items, create a copy of the selected item and delete the selected item,
respectively.

The rest should be pretty self-explanatory after you played with the editor
a while. You can also find some information at the POF specs webpage at
http://www.descent-freespace.com/ddn/specs/pof
This will explain the data blocks (a.k.a. "chunks") and their purpose.


Model Comparison Table
~~~~~~~~~~~~~~~~~~~~~~
The Model Comparison Table brings you an overview over the models in the
current HAM/HXM/HOG/VP archive. It is very useful to check how many vertices,
polygons, etc. a usual model has in the current game. It is also very useful
to check how many polygons for example a FreeSpace 2 can have at max *at
least*. You can easily do this by loading SPARKY_FS2.VP, going to
"Model|Model Comparison Table" and finally clicking on the "Polygons" column in
the table to sort via polygons. You will quickly see that the Colossus
(filename "TerranSuper") has the most with a total of 1924 polygons. So if you
plan your own model, you now know that as long as it has <=1924 polygons, you
don't have to fear that FreeSpace 2 can't load it because you exceeded the
polygon max. Same can be done of course with number of guns, submodels,
vertices, etc.

The following information is displayed for each model:
- Name (Filename)
- File version
- Filesize (of the model data for this model only)
- Number of vertices
- Number of polygons
- Number of textures
- Number of submodels
- Number of guns
- Number of positions (Descent 3 only)
- Number of subsystems (FreeSpace 1/2 only)
- Type of model (Descent 2 only, can be Robot, Reactor, Player Ship, Marker,
  Weapon combined with the flags LORES, DESTROYED, DYING and INNER.

Please note that in FreeSpace 1/2 the information for Detail level 1 is used,
when displaying vertices, polygons, textures and submodels. Other detail levels
can not be displayed via this dialog.


Positions
~~~~~~~~~
Both Descent 2 and Descent 3 support Positions. A position is basically
information, how the robot parts (submodels) are rotated to each other.
For example in Descent 2 there is a position for robots that is used whenever
the robot sleeps (has nothing to do). The "arms" and the "head" of the robot
are turned to the body then, to visualize that its inactive currently. Another
position defines how it holds it arms when it is hit: the arms are usually
spread open then.

Descent Manager MODELVIEW32 supports switching the current position for both
Descent 2 and Descent 3. However the advanced control bar on the right needs
to be turned on in the Options. This is however the default setting, so this
will only be turned off if you turned it off yourself.

To switch positions use the Positions list on the lower right in the advanced
control bar, which lists all positions, if there are any available.

FreeSpace 1/2 do not support positions, since these games deal with "ships",
not with "robots".


Textures
~~~~~~~~
In textured viewing mode MODELVIEW32 tries to load the textures of the current
model at the current places in the following order (top=highest priority):

Descent 2:
- From the PIG files (you can select which PIG file to use via the toolbar).
  (Note: POG file support is planned for a later version)

Descent 3:
- As OGF in the current directory.
- As OGF in the current HOG file. (if model is loaded from a HOG) 
- As OGF in the main HOG file. (*1)
- As OAF in the current directory.
- As OAF in the current HOG file. (if model is loaded from a HOG)
- As OAF in the main HOG file. (*1)

FreeSpace 1/2:
- As PCX in the current directory.
- As PCX in the current VP (if model is loaded from a VP).
- As PCX in the /data/maps directory of FreeSpace 1/2.
- As PCX in the main VP of FreeSpace 1/2. (*2)
- As ANI in the current directory.
- As ANI in the current VP (if model is loaded from a VP).
- As ANI in the /data/maps directory of FreeSpace 1/2.
- As ANI in the main VP of FreeSpace 1/2. (*2)

(*1) Main HOG is D3.HOG in the Descent 3 directory.
(*2) Main VP is data\freespace.vp for FreeSpace 1 and sparky_fs2.vp for
FreeSpace 2.


More notes about textures:
- Animations: MODELVIEW32 supports loading textures from animation files (like
  OAF in Descent 3 and ANI in FreeSpace 1/2), however does not display them as
  an animation then, instead only the first frame of the animation is loaded
  and displayed. Animations are in FreeSpace 1/2 for example used for the
  thrusters of the ships.

- On the right side of the screen you can see a list of the textures of the
  currently loaded FreeSpace model, if the "Textures" tab is selected (which
  is the case by default). If you click on one of them, MODELVIEW32 will filter
  all other textures in the model out and only display the polygons of the
  model that use the currently selected texture. (This works of course only in
  Textured Viewing mode.) Click on the entry "<All textures>" to display all
  again.

- To get more details about the textures of the currently loaded model,
  open the Details dialog (menu "Models|Models details"). You will get the
  following information for each texture used in the model:
  - Name
  - Location from where the texture was loaded (e.g. current directory or
    "Main HOG/VP")
  - Type (e.g. "PCX Texture" or "ANI Animation")
  - Width
  - Height
  - Used - this is the number of polygons using this specific texture


Subsystems
~~~~~~~~~~
Subsystems only exist in FreeSpace 1/2. They mark the engine, communications,
etc. part of a ship and can be destroyed independant of the whole ship. As a
result the pilot of a ship can't use the functionality of the destroyed
subsystem anymore unless s/he repairs it (for example if the engine is
destroyed, s/he is unable to move). You can usually target subsystems of an
already targeted ship by pressing the 'S' key (if you didn't remap it).

MODELVIEW32 can display subsystems - both hidden and "real" ones. Hidden
subsystems are points used internally by the game, for example that it knows
where to split a big ship when it gets destroyed. "Real" ones are the ones you
can actually target.

To show subsystems go to the right FreeSpace 1/2 game bar while a FreeSpace 1/2
model is loaded. There is a tab strip with "Textures", "Submodels" and
"Subsystems" - click the "Subsystems" tab. The list below will now show the
entry "<No subsystems>" as well as all found subsystems of the current model.
If the current model has no subsystem (like a missile), only the
"<No subsystems>" entry will be shown.

If you now click on one of the entries, the subsystem's area will be shown by
a yellow box. The center of the box is the center of the subsystem. The larger
the box is, the larger the radius of the subsystem.

Notes:
- If you can't see the yellow box for some subsystems, it might be hidden in
  the model itself. This is for example the case for most subsystems in the
  FreeSpace 2 model base2r-01. On some models also the hidden subsystems are
  too tiny to see (because the radius was set very small by the model author).

- Hidden subsystems are marked with "(hidden)" in the list.

- Turrets are not subsystems and so are not listed here. Check under "Guns"
  to view and analyse them.




<more information to come>