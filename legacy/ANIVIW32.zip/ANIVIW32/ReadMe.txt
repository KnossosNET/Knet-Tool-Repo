******************************************************************************
|  Descent Manager ANIVIEW32 V1.1  | http://www.descent-network.com/descman  |
|    Code by HH-Software Images    |                                         |
| (C)1999-2000 by Descent Network  | eMail: DescMan@descent-network.com      |
|----------------------------------|                                         |
|           Documentation          | Heiko Herrmann                          |
|           Release Notes          | Descent Network Team                    |
******************************************************************************


How to install ANIVIEW32:
~~~~~~~~~~~~~~~~~~~~~~~~~
- Run the installation EXE you downloaded and specify your destination
  directory. No DLLPAK is needed for this tool. However you need to have the
  font Tahoma installed. This is automatically installed by MS Office 97,
  MS Office 2000, DLLPAK and Windows 2000. If you don't have any of these
  installed, download the font from the website
  http://www.descent-network.com/descman
  and install it via the control panel.
 

Supported versions
~~~~~~~~~~~~~~~~~~
- Descent: FreeSpace, Playable Demo
- Descent: FreeSpace (US and ROW versions)
- Conflict: FreeSpace (UK, French and German versions)
- Darkness Rising OEM versions
- FreeSpace 2: Playable Demo
- FreeSpace 2 (Full version)


System Requirements
~~~~~~~~~~~~~~~~~~~
- Any FreeSpace-capable PC.
- At least 4 MB of free HD space.
- Windows 95, Windows 98, Windows ME, Windows NT 4.0 or Windows 2000.


What are ANI files
~~~~~~~~~~~~~~~~~~
ANI files are Volition ANImation files, so far used in their games
Conflict, Descent: FreeSpace and FreeSpace 2. This ANI file format is NOT a
standard file format and can so NOT be opened by a standard graphic tool like
Paint Shop Pro, Corel PhotoPaint, Adobe Photoshop, ACDSee or whatever.
With Descent Manager ANIVIEW32 however you can not only open and play them,
but also save them to AVI files, which can be played by any AVI player incl.
MS Media Player and Real Player.


Key frames
~~~~~~~~~~
Each ANI file can have any number of key frames. Key frames are frames that
are saved completely in the ANI instead of just as what pixels changed since
the previous frame. Normally ANI files in FreeSpace 1/2 have:

a) 1 keyframe (frame #0)
   The animation is played as is in the game, in most case also looped.

b) 2 keyframes (frame #0 and a "looppoint" frame)
   The animation has an "intro", only the part after the looppoint till the end
   is actually looped in the 2nd turn (e.g. the weapons and ships animations of
   the briefing screen). If you play such an ANI in ANIVIEW32 with loop enabled
   ANIVIEW32 will use this looppoint and so have the same effect as in the
   game.

c) all frames are keyframes
   The animation can be played forwards and backwards. This is the case for all
   main hall animations: its played forwards if you move the mouse pointer over
   a room, and backwards again if you move it away. If you play such an ANI in
   ANIVIEW32 with loop enabled ANIVIEW32 will play it bouncing forwards and
   backwards.

ANIVIEW32 only goes via the special loop modes as explained in b) and c), when
looping is enabled. Selecting "Previous Next frame" manually is not influenced
by the number of keyframes.


Integration in VPVIEW32
~~~~~~~~~~~~~~~~~~~~~~~
All ANI files are integrated in .VP files on both your FreeSpace CDs and your
game directory. Thats why you need a VP viewer to extract them first in order
to open them in ANIVIEW.

We however highly recommend to use our own tool Descent Manager VPVIEW32
(Version 1.1 or higher), since it automatically integrates with Descent
Manager ANIVIEW32, once both are installed. All you got to do then is go
to the Options dialog (Menu "File") in VPVIEW32, go to the "Settings" tab and
specify "Descent Manager ANIVIEW32" as the current viewer for ANI files.
VPVIEW32 will automatically find ANIVIEW32's directory. Please note that
ANIVIEW32 only will be listed as an option if you actually have it installed,
otherwise this option will be invisible in VPVIEW32.

Now to open an ANI file in VPVIEW32, just double-click on it. ANIVIEW32 will
open and you can play it from there or save it as an AVI. Its as easy as that.

The big advantage of VPVIEW32 is, that it integrates so highly with ANIVIEW32,
that it actually doesn't need to temporarily extract the ANI file but just
says ANIVIEW32 at which offset within the VP file it can find the ANI file.
This saves you some hard disk space.


Other notes
~~~~~~~~~~~
- If you want to save as AVI, you will be prompted which compression you want
  to use. You can usually use any that you have listed in the Multimedia applet
  of the Control Panel under "Advanced". "Microsoft Video 1" is quite
  recommendable in file size, speed and quality. Some compression formats might
  not work because the resolution for example is not the one expected by that
  codec. Try a different one then. Note that no codec seems to really reach
  the quality of the ANI file itself.

- GIF support is not available, and will probably never will because of Unisys'
  stupid license stuff.

- JPG support is not available, since JPGs are 24-bit, and ANIs are 8-bit.
  Also JPG has a quality-loss, so I don't think its worth to support it. If
  you really need frame(s) as JPG, save it/them in one of the supported formats
  and use one of the numerous image format converter utility available on the
  net.

- When playing large animations in Zoom x2 mode, your system might be too slow
  to actually gain 15 fps. Switch to non-Zoom x2 mode instead.

- ANIVIEW32 can only load ANI files, and optionally save as AVI files or save
  frames as BMP, PCX, TIF and TGA files. There is no way to go the other way,
  or build a ANI file at all within ANIVIEW32.
  However you can use the module Descent Manager ANIBUILDER32 to create ANI
  files. Go to the About menu under "Useful Tools" to get that tool if you do
  not already have it with FREESPACE KIT. Afterwards you can directly call
  ANIBUILDER32 from within ANIVIEW32 via the Tools menu.
  Alternatively you can use the command-line driven ACANI tool, which however
  has far less features.

- ANIVIEW32 loads the complete file into memory before playing it to ensure
  the frames can be accessed fast enough. This however might exceed the amount
  of free memory on your system and not all frames are actually loaded, or the
  tool might even crash, when trying to load real big ANI files. If you have
  multiple sessions of ANIVIEW32 running, try to close the others. If that does
  not help, try to extend your virtual memory.
  If you want to play ANIs already while loading (for example to quickly browse
  within a list of ANI files within a VP file), check VPVIEW32 V2.0 out
  (Check "Useful Tools" in the About box for how to get it).

- The tool behaves strangely under Windows NT 3.51. While it seems to work fine
  for one ANI, it crashes after you try to load the next in the current
  session. We won't investigate this nearer, since I doubt many FreeSpace fans
  are using this operating system, especially since FreeSpace does not run
  under NT 3.51. The tool runs fine under Windows NT 4.0 and of course
  Windows 2000 (=NT 5.0). The home operating systems Windows 95 and 98 are
  supported as well.

- ANIVIEW32 is unable to load the Windows animated cursor file format, which
  also has the file extension *.ANI. Only ANI files from the Volition titles
  FreeSpace 1 and FreeSpace 2 are supported, which are all saved within the
  *.VP files (use Descent Manager VPVIEW32 to open them, also see caption
  "Integration in VPVIEW32" above).

- Descent: FreeSpace Playable Demo has a file called NUMBERS01.ANI in the
  DATA\FREESPACE.VP file. Its not a real ANI file, it just uses that extension.
  Out of this reason it is not supported by ANIVIEW32. An error message will be
  displayed if you try to load it.


Disclaimer, Legal Section
~~~~~~~~~~~~~~~~~~~~~~~~~
This tool was coded by Heiko Herrmann and produced by the Descent Network Team.
By no means this tool is supported by the creators of Conflict, Descent:
FreeSpace, Volition Inc. and Interplay Productions. Furthermore, Descent
Network Team does not give you any guarantees.

Free support is available via DescMan@descent-network.com. We will try to help
you with any problem, but we can't guarantee that we will succeed in doing so.

This program may not be sold without our permission. Distribution is allowed
and wished as long as (a) only the original and unmodified distribution package
ANIVIEW11.EXE is being given away (this includes that you must not convert or
pack the file using any other archiver like ZIP, etc.) and (b) no fee is being
charged.

If you are interested in putting this tool on a shareware CD, magazine, or any-
thing else, you are welcomed to ask us via eMail: DescMan@descent-network.com.
Let us know what kind of magazine that is and where it is sold. If we agree, we
demand one free issue of that magazine being sent to us. In return however,
chances are big that we come up with a special version of the tool with the
note "Special edition for <insert magazine name here>" e.g. in the splash
screen and the title bar.

Descent Network Team denies to give you ANY warranty on this tool, especially
but not only when the tool is being installed on a messed up system or user
errors are made. We do believe the tool to be bug free and pretty stable
against human failure, but there is no warranty on that.




CU in the mines...
Heiko Herrmann alias HH-Software Images from the Descent Network Team
