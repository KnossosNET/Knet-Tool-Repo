******************************************************************************
|  Descent Manager VPVIEW32 V2.0   | http://www.descent-network.com/descman  |
|    Code by HH-Software Images    |                                         |
| (C)1998-2002 by Descent Network  | eMail: DescMan@descent-network.com      |
|----------------------------------|                                         |
|           Documentation          | Heiko Herrmann                          |
|           Release Notes          | Descent Network Team                    |
******************************************************************************


Supported games
~~~~~~~~~~~~~~~
VPVIEW32 supports opening data files demo, OEM, full and PlayStation versions
of:

- Conflict, Descent: FreeSpace - The Great War
- FreeSpace 2
- Summoner
- Red Faction

In FreeSpace games the data files have the extension .VP
In Summoner and Red Faction games the data files have the extension .VPP


New packaged TBL viewer
~~~~~~~~~~~~~~~~~~~~~~~
Since V2.0 Beta 05 we package a light edition of Descent Manager TBLVIEW32
together with VPVIEW32. Unlike the normal edition it does not display the
table in an actual table but in plain text, however formatted and with a
quick jump index provided at the left of the window.

Descent Manager TBLVIEW32 V2.0 Light Edition requires at least Microsoft
Internet Explorer 3.0 to be installed on your system. If you are running
Windows 98, ME, 2000, XP or .NET or anything newer than those, you have
Internet Explorer already installed with the operating system. If you have
Windows 95 or NT 4.0, you need to make sure you have installed it. You can
get MS Internet Explorer for free at http://www.microsoft.com/windows/ie


Coexistance of TBLVIEW32 V1.0 and TBLVIEW32 V2.0 Light Edition
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
The original Descent Manager TBLVIEW32 V1.0 was primary coded for FreeSpace
tables, however it still works for some Red Faction and Summoner stuff. The
primary feature of that tool was a table format where you could compare and
sort specific data, for example find out the fastest or the hardest weapon.
Descent Manager TBLVIEW32 V1.0 is not supported anymore, however still
available for download for some time at
http://www.descent-network.com/cgi-bin/descman.cgi?module=tblview

The new Descent Manager TBLVIEW32 V2.0 is a newly coded viewer which displays
the TBL file in plain text, but color formatted. Since there is no actual
"table" view anymore and so the V2.0 functionality does not supercede the
V1.0 functionality yet, we decided to add "Light Edition" to the name of the
tool for now, to make clear that the tool does not do the same thing as V1.0.

Chances are good that a "non-light" edition of V2.0 will come out some day
which will have both color-formatted and tabled view, so look out for it.

As for the coexistance of V1.0 and V2.0 Light on one system there is the
following to say:little

- Both can coexist, however of course you can only use one primarily
  to be assigned as the tool to be loaded when double-clicking TBL files
  from Explorer or VPVIEW32 V2.0.

- This "primary" tool might change from time to time, when you have both
  VPVIEW32 V2.0 set to assign TBL with TBLVIEW32 V2.0 Light and
  TBLVIEW32 V1.0 set to assign TBL with itself. Best is that you only set
  ONE tool to be the official "TBL" file program.

- To make this whole thing even more complex ;-): Note that VPVIEW32 V1.0
  can use TBLVIEW32 V1.0 to always start, while Explorer and VPVIEW32 V2.0
  being using TBLVIEW V2.0 Light. Weird, eh ;)?


Difference between VPVIEW32 V1.0 and V2.0
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
VPVIEW32 2.0 was completely recoded in VC++.

Major news since V1.x include:
- No DLLPAK needed anymore.
- Loading .VP files is a lot faster.
- Included previewer for .ANI, .VBM, .TGA and .PCX files (VPVIEW32 1.x only
  had a .WAV-file previewer).
- Support for Summoner and Red Faction (VPP files).
- Lots of new small features, like the "File Info" tab and more.



Known bugs+limitations:
~~~~~~~~~~~~~~~~~~~~~~~
+ Date display seems to be incorrect (at least it shows different dates as
  VPVIEW32 V1.x).
- On extraction there is no check whether the files could be written correctly.
  Even if there were errors (like "disk full") the tool will say files were
  successfully extracted.
- Not yet implemented functions:
  -*Double-clicking of folders to open subfolders is not yet implemented for
    the right view.


VPVIEW32 V1.x and this V2.0 Beta
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Both versions can co-exist on the same system, and you can install them in any
order, as long as you install them to seperate directories.




CU in the mines...
Heiko Herrmann alias HH-Software Images from the Descent Network Team
